import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-imagedetails',
  templateUrl: './imagedetails.component.html',
  styleUrls: ['./imagedetails.component.css']
})
export class ImagedetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
